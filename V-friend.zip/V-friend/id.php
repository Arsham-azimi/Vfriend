<?php
// دریافت داده از فایل JSON
$jsonData = file_get_contents('https://arsham-kurd.ir/app/data.json');

// تبدیل داده به آرایه
$dataArray = json_decode($jsonData, true);

// شمارش تعداد مپ‌ها
$mapCount = is_array($dataArray) ? count($dataArray) : 0;

// نمایش فقط عدد
echo $mapCount;
?>