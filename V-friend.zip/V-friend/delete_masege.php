<?php

function removeMessageById($jsonFile, $messageId) {
    // خواندن محتویات فایل JSON
    $jsonData = file_get_contents($jsonFile);
    
    // تبدیل داده‌ها به آرایه
    $dataArray = json_decode($jsonData, true);

    // بررسی اعتبار تبدیل JSON
    if ($dataArray === null) {
        die(json_encode(["error" => "خطا در پردازش JSON"]));
    }

    // فیلتر کردن فقط آیتمی که `id_m` مشخص‌شده دارد
    $filteredArray = array_filter($dataArray, function ($item) use ($messageId) {
        return !(isset($item['id_m']) && $item['id_m'] == $messageId);
    });

    // ذخیره آرایه جدید در فایل JSON
    file_put_contents($jsonFile, json_encode(array_values($filteredArray), JSON_PRETTY_PRINT));

    return ["success" => "پیام با آیدی $messageId حذف شد"];
}

// بررسی دریافت آیدی پیام از طریق GET
if (isset($_GET['id_m']) && !empty($_GET['id_m'])) {
    $messageId = $_GET['id_m']; // آیدی پیام

    // مسیر فایل JSON
    $jsonFile = 'conversations.json';

    // اجرای حذف
    $response = removeMessageById($jsonFile, $messageId);

    // تنظیم هدر و نمایش نتیجه
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo json_encode(["error" => "لطفاً یک آیدی معتبر وارد کنید."]);
}

?>