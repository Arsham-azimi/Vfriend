<?php

header("Content-Type: application/json; charset=UTF-8");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$api_url = "https://api-free.ir/api/chat.php";
$conversation_file = 'conversations.json';

// بررسی و ایجاد فایل JSON در صورت نبودن
if (!file_exists($conversation_file)) {
    file_put_contents($conversation_file, json_encode([]));
}

// بارگذاری مکالمات قبلی
$conversations = json_decode(file_get_contents($conversation_file), true) ?: [];

// بررسی ورود اطلاعات
if (!isset($_GET['text']) || !isset($_GET['id'])) {
    echo json_encode(["text" => "متن یا آیدی ارائه نشده است"]);
    exit;
}

// دریافت اطلاعات کاربر
$user_text = trim($_GET['text']);
$user_id   = trim($_GET['id']);
$user_info = isset($_GET['user']) && !empty(trim($_GET['user']))
             ? trim($_GET['user'])
             : "دوست عزیز";
$mode      = isset($_GET['mode']) ? trim($_GET['mode']) : "normal"; // حالت پیش‌فرض

// استخراج اطلاعات کاربر از پیام (مانند نام، سن، علاقه)
preg_match('/من ([\w\s]+) هستم\s?(\d+)?\s?(و\s*علاقه به ([\w\s]+) دارم)?/u', $user_text, $matches);
$user_name     = $matches[1] ?? null;
$user_age      = $matches[2] ?? null;
$user_interest = $matches[4] ?? null;

// ایجاد پیام خوشامدگویی شخصی‌سازی‌شده (برای کاربر جدید)
$intro_message = $user_name 
    ? "سلام {$user_name}" . ($user_age ? " {$user_age} ساله" : "") . ($user_interest ? " که به {$user_interest} علاقه‌مند هستی" : "") . "! چطوری؟ 😊" 
    : "سلام {$user_info}! من نورا هستم، دوست صمیمی و همراه تو!";

// بررسی وجود کاربر در فایل (بر اساس آیدی)
$user_exists = false;
foreach ($conversations as $msg) {
    if (isset($msg["id"]) && $msg["id"] === $user_id) {
        $user_exists = true;
        break;
    }
}

if (!$user_exists) {
    $conversations[] = [
        "id"     => $user_id,
        "text1"  => $user_text,
        "text"   => $intro_message,
        "id_m"   => uniqid()
    ];
    
    echo json_encode(["text" => $intro_message]);
    file_put_contents($conversation_file, json_encode($conversations, JSON_PRETTY_PRINT));
    exit;
}

// دریافت مکالمات قبلی کاربر بر اساس آی‌دی و محدود به **آخرین دو پیام** برای جلوگیری از خطا
$filtered_messages = array_values(array_filter($conversations, fn($msg) => isset($msg["id"]) && $msg["id"] === $user_id));
$filtered_messages = array_slice($filtered_messages, -2, 2);

$previous_messages = "";
foreach ($filtered_messages as $msg) {
    $previous_messages .= "کاربر: " . $msg["text1"] . "\nنورا: " . $msg["text"] . "\n";
}

$prompt = "";

switch ($mode) {
    case "analysis":
        $prompt = "تحلیل روانشناسی انجام بده و پاسخ همدلانه ارائه بده. بررسی کن که کاربر در گذشته چه چیزی گفته و چگونه احساس کرده است."
                . "\nمکالمات قبلی (آخرین ۲ پیام):\n" . $previous_messages
                . "کاربر: \"$user_text\"";
        break;
        
    case "focus":
        $prompt = "یک فضای آرامش‌بخش و بدون حواس‌پرتی برای کاربر ایجاد کن. پیام‌های ساده و ملایم بفرست."
                . "\nمکالمات قبلی (آخرین ۲ پیام):\n" . $previous_messages
                . "کاربر: \"$user_text\"";
        break;
        
    case "listen":
        // پیدا کردن آخرین ورودی مکالمه کاربر بر اساس آی‌دی
        $lastUserKey = null;
        foreach ($conversations as $key => $msg) {
            if (isset($msg["id"]) && $msg["id"] === $user_id) {
                $lastUserKey = $key;
            }
        }
        if ($lastUserKey !== null) {
            if (!isset($conversations[$lastUserKey]["all_messages"])) {
                $conversations[$lastUserKey]["all_messages"] = [];
            }
            $conversations[$lastUserKey]["all_messages"][] = $user_text;
            // محدود کردن پیام‌های گوش دادن به آخرین ۲ پیام
            if (count($conversations[$lastUserKey]["all_messages"]) > 2) {
                $conversations[$lastUserKey]["all_messages"] = array_slice($conversations[$lastUserKey]["all_messages"], -2, 2);
            }
        }
        // اگر کاربر نگفته "تموم شدم"، پاسخ کوتاه بده و بپرس: "تموم شدی؟"
        if (strpos($user_text, "تموم شدم") === false) {
            echo json_encode(["text" => "خیلی خوب، ادامه بده. تموم شدی؟"]);
            file_put_contents($conversation_file, json_encode($conversations, JSON_PRETTY_PRINT));
            exit;
        } else {
            if ($lastUserKey !== null && isset($conversations[$lastUserKey]["all_messages"])) {
                $all_messages = implode("\n", $conversations[$lastUserKey]["all_messages"]);
            } else {
                $all_messages = "";
            }
            $prompt = "مکالمه را ادامه بده و تحلیل نهایی ارائه بده."
                    . "\nمکالمه کامل (آخرین ۲ پیام):\n" . $all_messages
                    . "\nو همچنین به تاریخچه گفتگوی ما (آخرین ۲ پیام) توجه کن:\n" . $previous_messages;
        }
        break;
        
    default: // Normal mode – اطلاعات فرد و آخرین دو پیام مکالمات قبلی
        $user_details = "";
        if ($user_name !== null) {
            $user_details .= "نام: " . $user_name;
            if ($user_age !== null) {
                $user_details .= ", سن: " . $user_age;
            }
            if ($user_interest !== null) {
                $user_details .= ", علاقه: " . $user_interest;
            }
        } else {
            $user_details = $user_info;
        }
        
        $prompt = "مانند یک روانشناس، دوست صمیمی، مشاور و خانواده باش! همیشه همدلانه گوش بده، بدون قضاوت. "
         . "اطلاعات کاربر به صورت مستقیم: " . $user_details . ". "
         . "مکالمه را بر اساس این اطلاعات شخصی‌سازی کن. "
         . "اگر احساسش را بیان کرد، مانند یک دوست واقعی با او همراه شو، مکالمه را گرم نگه دار، و کمک کن حس بهتری پیدا کند. "
         . "\nمکالمات قبلی (آخرین ۲ پیام):\n" . $previous_messages
         . "کاربر: \"$user_text\"";
        break;
}

// ارسال درخواست به API
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(["text" => $prompt]));
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$reply = $result && isset($result["result"])
         ? trim($result["result"])
         : "متأسفم، پاسخی دریافت نشد.";

$conversations[] = [
    "id"    => $user_id,
    "text1" => $user_text,
    "text"  => $reply,
    "id_m"  => uniqid()
];

echo json_encode(["text" => $reply]);

file_put_contents($conversation_file, json_encode($conversations, JSON_PRETTY_PRINT));

?>