<?php
// مسیر فایل JSON
$file = 'data.json';

// بررسی وجود فایل و خواندن محتوا
if (file_exists($file)) {
    $existingData = json_decode(file_get_contents($file), true);
} else {
    $existingData = [];
}

// دریافت داده‌های GET
$name = isset($_GET['name']) ? $_GET['name'] : "Unknown";
$id = isset($_GET['id']) ? $_GET['id'] : "";
$ban = isset($_GET['ban']) ? filter_var($_GET['ban'], FILTER_VALIDATE_BOOLEAN) : false;

// بررسی اینکه آیا id قبلاً وجود دارد
$idExists = false;
foreach ($existingData as $entry) {
    if ($entry['id'] === $id) {
        $idExists = true;
        break;
    }
}

// اگر id وجود نداشت، داده جدید را اضافه کن
if (!$idExists && !empty($id)) {
    $data = [
        "name" => $name,
        "id" => $id,
        "ban" => $ban
    ];

    $existingData[] = $data;
    file_put_contents($file, json_encode($existingData, JSON_PRETTY_PRINT));
    echo "✅ اطلاعات جدید اضافه شد.";
} else {
    echo "⚠️ این ID قبلاً وجود دارد یا مقدار آن معتبر نیست.";
}
?>