<?php

function searchJsonById($jsonFile, $searchId) {
    // خواندن محتویات فایل JSON
    $jsonData = file_get_contents($jsonFile);
    
    // تبدیل داده‌ها به آرایه
    $dataArray = json_decode($jsonData, true);

    // بررسی اعتبار تبدیل JSON
    if ($dataArray === null) {
        die(json_encode(["error" => "خطا در پردازش JSON"]));
    }

    // لیست‌هایی که دارای آیدی مورد نظر هستند
    $result = [];

    // پیمایش داده‌ها برای یافتن آیتم‌هایی با آیدی مشخص
    foreach ($dataArray as $item) {
        if (isset($item['id']) && $item['id'] == $searchId) {
            $result[] = $item;
        }
    }

    return $result;
}

// بررسی دریافت آیدی از طریق GET
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $searchId = $_GET['id'];
    
    // مسیر فایل JSON
    $jsonFile = 'conversations.json';

    // اجرای جستجو
    $foundItems = searchJsonById($jsonFile, $searchId);

    // تنظیم هدر و نمایش نتایج
    header('Content-Type: application/json');
    echo json_encode($foundItems, JSON_PRETTY_PRINT);
} else {
    echo json_encode(["error" => "لطفاً یک آیدی معتبر وارد کنید."]);
}

?>