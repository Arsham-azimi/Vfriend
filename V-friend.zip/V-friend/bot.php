<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
// تنظیمات امنیتی
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // اگر از HTTPS استفاده می‌کنید، این را به 1 تغییر دهید
}

// تولید CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// اعتبارسنجی CSRF Token برای درخواست‌های POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('درخواست نامعتبر است');
    }
}

// تنظیم کوکی برای ذخیره شناسه دائمی کاربر (مدت 1 سال)
if (!isset($_COOKIE['persistent_id'])) {
    $persistentId = substr(md5(uniqid(rand(), true)), 0, 12);
    setcookie('persistent_id', $persistentId, time() + (365 * 24 * 60 * 60), "/", "", false, true);
} else {
    $persistentId = $_COOKIE['persistent_id'];
}

$_SESSION['persistent_id'] = $persistentId;

// بررسی وضعیت حساب کاربر از فایل data.json
function checkUserStatus($id) {
    $dataFile = 'data.json';
    
    if (file_exists($dataFile)) {
        $jsonData = file_get_contents($dataFile);
        $data = json_decode($jsonData, true);
        
        if (isset($data[$id])) {
            return $data[$id]['ban'];
        }
    }
    
    return null; // کاربر وجود ندارد
}

// بررسی وضعیت کاربر
$userStatus = checkUserStatus($persistentId);

// اگر کاربر بن شده باشد، به صفحه بن هدایت می‌شود
if ($userStatus === true) {
    header("Location: banned.php");
    exit();
}

// اگر کاربر وجود ندارد یا قبلا ثبت نام نکرده، به صفحه ثبت‌نام هدایت می‌شود
if (($userStatus === null || !isset($_SESSION['registered'])) && !isset($_POST['action']) && basename($_SERVER['PHP_SELF']) !== 'banned.php') {
    $_SESSION['needs_registration'] = true;
}

// توابع برای ارتباط با API
function createAccount($id, $name) {
    $url = "https://arsham-kurddev.ir/V-friend/user.php?name=" . urlencode($name) . "&ban=false&id=" . urlencode($id);
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    
    // ذخیره اطلاعات کاربر در فایل data.json
    if (strpos($response, '✅') !== false) {
        $dataFile = 'data.json';
        $data = [];
        
        if (file_exists($dataFile)) {
            $jsonData = file_get_contents($dataFile);
            $data = json_decode($jsonData, true);
        }
        
        $data[$id] = [
            'name' => $name,
            'ban' => false,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        file_put_contents($dataFile, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    
    return $response;
}

function deleteAllMessages($id) {
    $url = "https://www.arsham-kurddev.ir/V-friend/delete.php?id=" . urlencode($id);
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function getMotivationalQuote() {
    $url = "https://www.arsham-kurddev.ir/V-friend/text.php";
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function sendMessage($id, $text, $about, $mode) {
    $url = "https://www.arsham-kurddev.ir/V-friend/name.php?id=" . urlencode($id) . "&text=" . urlencode($text) . "&user=" . urlencode($about) . "&mode=" . urlencode($mode);
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function deleteMessage($messageId) {
    $url = "https://www.arsham-kurddev.ir/V-friend/delete_masege.php?id_m=" . urlencode($messageId);
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function getMessages($id) {
    $url = "https://www.arsham-kurddev.ir/V-friend/serch.php?id=" . urlencode($id);
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: V-Friend-App\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

// پردازش فرم‌ها
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $persistentId = $_SESSION['persistent_id'];
        
        switch ($_POST['action']) {
            case 'register':
                $name = htmlspecialchars($_POST['name'] ?? 'کاربر', ENT_QUOTES, 'UTF-8');
                $result = createAccount($persistentId, $name);
                if (strpos($result, '✅') !== false) {
                    $_SESSION['registered'] = true;
                    $_SESSION['user_name'] = $name;
                    // ذخیره در کوکی برای مدت طولانی
                    setcookie('user_name', $name, time() + (365 * 24 * 60 * 60), "/", "", false, true);
                    setcookie('rules_accepted', 'true', time() + (365 * 24 * 60 * 60), "/", "", false, true);
                    unset($_SESSION['needs_registration']);
                    
                    // ریدایرکت برای جلوگیری از ثبت مجدد
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                } else {
                    $_SESSION['register_error'] = "خطا در ثبت نام. لطفاً دوباره تلاش کنید.";
                }
                break;
                
            case 'send_message':
                if (!isset($_SESSION['registered'])) {
                    break;
                }
                $text = htmlspecialchars($_POST['message_text'] ?? '', ENT_QUOTES, 'UTF-8');
                $about = $_SESSION['about'] ?? '';
                $mode = htmlspecialchars($_POST['mode'] ?? 'normal', ENT_QUOTES, 'UTF-8');
                $response = sendMessage($persistentId, $text, $about, $mode);
                break;
                
            case 'delete_all':
                $result = deleteAllMessages($persistentId);
                break;
                
            case 'save_profile':
                $_SESSION['user_name'] = htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8');
                $_SESSION['age'] = htmlspecialchars($_POST['age'] ?? '', ENT_QUOTES, 'UTF-8');
                $_SESSION['about'] = htmlspecialchars($_POST['about'] ?? '', ENT_QUOTES, 'UTF-8');
                $_SESSION['interests'] = htmlspecialchars($_POST['interests'] ?? '', ENT_QUOTES, 'UTF-8');
                $_SESSION['favorite_color'] = htmlspecialchars($_POST['favorite_color'] ?? '', ENT_QUOTES, 'UTF-8');
                $_SESSION['personality'] = htmlspecialchars($_POST['personality'] ?? '', ENT_QUOTES, 'UTF-8');
                // ذخیره در کوکی
                setcookie('user_name', $_SESSION['user_name'], time() + (365 * 24 * 60 * 60), "/", "", false, true);
                break;
                
            case 'delete_message':
                $messageId = htmlspecialchars($_POST['message_id'] ?? '', ENT_QUOTES, 'UTF-8');
                if (!empty($messageId)) {
                    $result = deleteMessage($messageId);
                }
                break;
                
            case 'accept_rules':
                $_SESSION['rules_accepted'] = true;
                setcookie('rules_accepted', 'true', time() + (365 * 24 * 60 * 60), "/", "", false, true);
                break;
                
            case 'change_theme':
                $theme = htmlspecialchars($_POST['theme'] ?? 'light', ENT_QUOTES, 'UTF-8');
                if (in_array($theme, ['light', 'dark'])) {
                    $_SESSION['theme'] = $theme;
                    setcookie('theme', $theme, time() + (365 * 24 * 60 * 60), "/", "", false, true);
                }
                break;
                
            case 'change_color':
                $color_scheme = htmlspecialchars($_POST['color_scheme'] ?? 'default', ENT_QUOTES, 'UTF-8');
                if (in_array($color_scheme, ['default', 'blue', 'green', 'red', 'orange', 'purple', 'pink', 'teal'])) {
                    $_SESSION['color_scheme'] = $color_scheme;
                    setcookie('color_scheme', $color_scheme, time() + (365 * 24 * 60 * 60), "/", "", false, true);
                }
                break;
                
            case 'search_messages':
                // جستجو در پیام‌ها - پیاده‌سازی در سمت کلاینت
                break;
        }
        
        // جلوگیری از ارسال مجدد فرم با رفرش صفحه
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

// بررسی کوکی‌ها برای بارگذاری تنظیمات ذخیره شده
if (!isset($_SESSION['rules_accepted']) && isset($_COOKIE['rules_accepted'])) {
    $_SESSION['rules_accepted'] = $_COOKIE['rules_accepted'] === 'true';
}

if (!isset($_SESSION['registered']) && isset($_COOKIE['user_name'])) {
    $_SESSION['registered'] = true;
    $_SESSION['user_name'] = $_COOKIE['user_name'];
}

if (!isset($_SESSION['theme']) && isset($_COOKIE['theme'])) {
    $_SESSION['theme'] = $_COOKIE['theme'];
}

if (!isset($_SESSION['color_scheme']) && isset($_COOKIE['color_scheme'])) {
    $_SESSION['color_scheme'] = $_COOKIE['color_scheme'];
}

// دریافت نقل قول انگیزشی
$motivationalQuote = getMotivationalQuote();
$quoteText = $motivationalQuote['Text'] ?? 'امروز روز خوبی برای تو خواهد بود!';

// دریافت پیام‌ها اگر کاربر ثبت‌نام کرده
$messages = [];
if (isset($_SESSION['registered'])) {
    $persistentId = $_SESSION['persistent_id'];
    $messagesData = getMessages($persistentId);
    
    // پردازش پیام‌ها برای نمایش صحیح
    if (is_array($messagesData)) {
        foreach ($messagesData as $message) {
            if (isset($message['text1']) && !empty($message['text1'])) {
                $messages[] = [
                    'sender' => 'user',
                    'text' => $message['text1'],
                    'id' => $message['id_m'] ?? uniqid()
                ];
            }
            
            if (isset($message['text']) && !empty($message['text'])) {
                $messages[] = [
                    'sender' => 'bot',
                    'text' => $message['text'],
                    'id' => ($message['id_m'] ?? uniqid()) . '-bot'
                ];
            }
        }
    }
}

// بررسی اینکه آیا کاربر قوانین را پذیرفته
$rulesAccepted = $_SESSION['rules_accepted'] ?? false;

// تنظیم تم
$currentTheme = $_SESSION['theme'] ?? 'light';
$currentColorScheme = $_SESSION['color_scheme'] ?? 'default';

// تنظیم رنگ‌ها بر اساس تم انتخاب شده
if ($currentTheme === 'dark') {
    if ($currentColorScheme === 'blue') {
        $primaryColor = '#3498db';
        $secondaryColor = '#2980b9';
    } elseif ($currentColorScheme === 'green') {
        $primaryColor = '#27ae60';
        $secondaryColor = '#229954';
    } elseif ($currentColorScheme === 'red') {
        $primaryColor = '#e74c3c';
        $secondaryColor = '#c0392b';
    } elseif ($currentColorScheme === 'orange') {
        $primaryColor = '#f39c12';
        $secondaryColor = '#e67e22';
    } elseif ($currentColorScheme === 'purple') {
        $primaryColor = '#9b59b6';
        $secondaryColor = '#8e44ad';
    } elseif ($currentColorScheme === 'pink') {
        $primaryColor = '#e84393';
        $secondaryColor = '#fd79a8';
    } elseif ($currentColorScheme === 'teal') {
        $primaryColor = '#00cec9';
        $secondaryColor = '#00b894';
    } else {
        $primaryColor = '#9b59b6';
        $secondaryColor = '#8e44ad';
    }
    $bgColor = '#1e272e';
    $cardBg = '#2f3640';
    $textColor = '#f5f6fa';
} else {
    if ($currentColorScheme === 'blue') {
        $primaryColor = '#3498db';
        $secondaryColor = '#2980b9';
    } elseif ($currentColorScheme === 'green') {
        $primaryColor = '#27ae60';
        $secondaryColor = '#229954';
    } elseif ($currentColorScheme === 'red') {
        $primaryColor = '#e74c3c';
        $secondaryColor = '#c0392b';
    } elseif ($currentColorScheme === 'orange') {
        $primaryColor = '#f39c12';
        $secondaryColor = '#e67e22';
    } elseif ($currentColorScheme === 'purple') {
        $primaryColor = '#9b59b6';
        $secondaryColor = '#8e44ad';
    } elseif ($currentColorScheme === 'pink') {
        $primaryColor = '#e84393';
        $secondaryColor = '#fd79a8';
    } elseif ($currentColorScheme === 'teal') {
        $primaryColor = '#00cec9';
        $secondaryColor = '#00b894';
    } else {
        $primaryColor = '#8e44ad';
        $secondaryColor = '#9b59b6';
    }
    $bgColor = '#f5f6fa';
    $cardBg = '#ffffff';
    $textColor = '#2f3640';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V-Friend - دوست هوشمند شما</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn/500.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        :root {
            --primary-color: <?php echo $primaryColor; ?>;
            --secondary-color: <?php echo $secondaryColor; ?>;
            --accent-color: #e056fd;
            --light-color: #f9f9f9;
            --dark-color: #1e272e;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --text-color: <?php echo $textColor; ?>;
            --bg-color: <?php echo $bgColor; ?>;
            --card-bg: <?php echo $cardBg; ?>;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --message-user-bg: <?php echo $primaryColor; ?>;
            --message-user-text: #fff;
            --message-bot-bg: #e0e0e0;
            --message-bot-text: #333;
        }

        [data-theme="dark"] {
            --message-bot-bg: #485460;
            --message-bot-text: #f5f6fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Vazirmatn', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: var(--transition);
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            opacity: 0;
            animation: fadeInBody 0.5s ease forwards;
        }

        @keyframes fadeInBody {
            to { opacity: 1; }
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 1rem;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: var(--shadow);
            animation: slideDown 0.5s ease;
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .nav-toggle:hover {
            transform: scale(1.1);
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 1.5rem;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.5rem;
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        nav ul li a:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .theme-toggle {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .theme-toggle:hover {
            transform: rotate(15deg) scale(1.1);
        }

        .quote-section {
            background-color: var(--card-bg);
            padding: 1.2rem;
            margin: 1.5rem 0;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
            font-style: italic;
            color: var(--primary-color);
            font-size: 1.2rem;
            animation: fadeIn 0.6s ease;
        }

        .main-content {
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        .chat-section {
            flex: 1;
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1.2rem;
            margin-bottom: 1.5rem;
            overflow-y: auto;
            max-height: 500px;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            animation: scaleIn 0.5s ease;
        }

        .message {
            padding: 0.7rem 0.9rem;
            border-radius: 18px;
            max-width: 80%;
            word-wrap: break-word;
            font-size: 0.85rem;
            position: relative;
            animation: fadeIn 0.4s ease;
            transform-origin: center;
            transition: all 0.3s ease;
        }

        .message.deleting {
            animation: slideOut 0.3s ease forwards;
        }

        @keyframes slideOut {
            to { transform: translateY(-20px); opacity: 0; height: 0; padding: 0; margin: 0; }
        }

        .user-message {
            background-color: var(--message-user-bg);
            color: var(--message-user-text);
            margin-left: auto;
            border-bottom-right-radius: 5px;
            animation: slideInRight 0.4s ease;
        }

        @keyframes slideInRight {
            from { transform: translateX(30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .bot-message {
            background-color: var(--message-bot-bg);
            color: var(--message-bot-text);
            margin-right: auto;
            border-bottom-left-radius: 5px;
            animation: slideInLeft 0.4s ease;
        }

        @keyframes slideInLeft {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .message-sender {
            font-size: 0.65rem;
            opacity: 0.8;
            margin-bottom: 0.3rem;
        }

        .message-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 0.4rem;
            gap: 0.5rem;
        }

        .message-actions button {
            background: rgba(0, 0, 0, 0.1);
            border: none;
            border-radius: 4px;
            padding: 0.2rem 0.5rem;
            cursor: pointer;
            font-size: 0.65rem;
            color: inherit;
            transition: all 0.2s;
        }

        .message-actions button:hover {
            background: rgba(0, 0, 0, 0.2);
            transform: scale(1.05);
        }

        .search-section {
            margin-bottom: 1rem;
            animation: fadeIn 0.5s ease;
        }

        .search-box {
            display: flex;
            gap: 0.5rem;
        }

        .search-box input {
            flex: 1;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            background-color: var(--card-bg);
            color: var(--text-color);
            font-size: 0.9rem;
        }

        .search-box button {
            padding: 0.8rem 1.2rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .input-section {
            display: flex;
            margin-bottom: 1.5rem;
            gap: 0.5rem;
            position: relative;
            animation: fadeIn 0.6s ease;
        }

        .input-section input {
            flex: 1;
            padding: 0.8rem 3rem 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            background-color: var(--card-bg);
            color: var(--text-color);
            font-size: 0.9rem;
        }

        .voice-record-btn {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--primary-color);
            cursor: pointer;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            transition: all 0.2s;
            z-index: 2;
        }

        .voice-record-btn:hover {
            background-color: rgba(0, 0, 0, 0.05);
            transform: translateY(-50%) scale(1.1);
        }

        .voice-record-btn.recording {
            color: var(--danger-color);
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { transform: translateY(-50%) scale(1); }
            50% { transform: translateY(-50%) scale(1.1); }
            100% { transform: translateY(-50%) scale(1); }
        }

        .input-section button {
            padding: 0.8rem 1.2rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .input-section button:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }

        .mode-selector {
            display: flex;
            justify-content: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 0.5rem;
            animation: fadeIn 0.7s ease;
        }

        .mode-button {
            padding: 0.6rem 1rem;
            background-color: var(--card-bg);
            border: 1px solid #ddd;
            border-radius: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            transition: all 0.2s;
        }

        .mode-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .mode-button.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .mode-button.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .profile-section, .rules-section, .about-section, .support-section {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            animation: scaleIn 0.5s ease;
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .form-group {
            margin-bottom: 1.2rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            font-size: 0.9rem;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            background-color: var(--card-bg);
            color: var(--text-color);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }

        .btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }

        .btn-success {
            background-color: var(--success-color);
            color: white;
        }

        .btn-warning {
            background-color: var(--warning-color);
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background-color: var(--card-bg);
            padding: 2rem;
            border-radius: var(--border-radius);
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: var(--shadow);
            animation: scaleIn 0.3s ease;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            position: relative;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--text-color);
            transition: all 0.2s;
            position: absolute;
            left: 0;
            top: 0;
        }

        .close-modal:hover {
            transform: rotate(90deg);
        }

        footer {
            background-color: var(--dark-color);
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: 2rem;
            animation: fadeIn 0.8s ease;
        }

        .hidden {
            display: none;
        }

        .color-picker {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }

        .color-option {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.2s;
        }

        .color-option:hover {
            transform: scale(1.1);
        }

        .color-option.active {
            border-color: var(--text-color);
            transform: scale(1.15);
        }

        /* رسپانسیو */
        @media (max-width: 768px) {
            .nav-toggle {
                display: block;
            }
            
            nav ul {
                display: none;
                flex-direction: column;
                position: absolute;
                top: 100%;
                right: 0;
                background-color: var(--primary-color);
                width: 100%;
                padding: 1rem;
                gap: 1rem;
                z-index: 1000;
                animation: slideDown 0.3s ease;
            }
            
            nav ul.show {
                display: flex;
            }
            
            .message {
                max-width: 90%;
                font-size: 0.8rem;
            }
            
            .header-content {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mode-button {
                font-size: 0.8rem;
                padding: 0.5rem 0.8rem;
            }
        }

        /* اسکرول بار سفارشی */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--secondary-color);
        }
        
        .settings-panel {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow);
            animation: fadeIn 0.6s ease;
        }
        
        .settings-title {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .theme-options {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .theme-option {
            padding: 0.5rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s;
        }
        
        .theme-option:hover {
            transform: translateY(-2px);
        }
        
        .theme-option.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .color-options {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .color-option.purple { background-color: #8e44ad; }
        .color-option.blue { background-color: #3498db; }
        .color-option.green { background-color: #27ae60; }
        .color-option.red { background-color: #e74c3c; }
        .color-option.orange { background-color: #f39c12; }
        .color-option.pink { background-color: #e84393; }
        .color-option.teal { background-color: #00cec9; }
        
        .message-actions .tts-button {
            background: rgba(255, 255, 255, 0.2);
            color: inherit;
        }
        
        .message-actions .share-button {
            background: rgba(255, 255, 255, 0.2);
            color: inherit;
        }
        
        .message-actions .tts-button:hover,
        .message-actions .share-button:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .tts-playing {
            position: relative;
        }
        
        .tts-playing::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 18px;
            background: rgba(255, 255, 255, 0.1);
            animation: pulse-border 1.5s infinite;
        }
        
        @keyframes pulse-border {
            0% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(52, 152, 219, 0); }
            100% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0); }
        }
        
        .screenshot-container {
            position: relative;
            background: white;
            border-radius: 12px;
            padding: 20px;
            max-width: 400px;
            margin: 0 auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .screenshot-message {
            margin-bottom: 15px;
            padding: 12px 15px;
            border-radius: 18px;
            max-width: 80%;
            word-wrap: break-word;
            font-size: 14px;
        }
        
        .screenshot-user {
            background-color: var(--primary-color);
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 5px;
        }
        
        .screenshot-bot {
            background-color: #e0e0e0;
            color: #333;
            margin-right: auto;
            border-bottom-left-radius: 5px;
        }
        
        .screenshot-logo {
            text-align: center;
            margin-bottom: 20px;
            color: var(--primary-color);
            font-weight: bold;
            font-size: 18px;
        }
        
        .screenshot-watermark {
            position: absolute;
            bottom: 10px;
            right: 10px;
            font-size: 10px;
            color: #aaa;
        }
        
        .no-messages {
            text-align: center;
            padding: 2rem;
            color: #888;
            font-style: italic;
        }
        
        .voice-status {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--primary-color);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            display: none;
            align-items: center;
            gap: 0.5rem;
            z-index: 3000;
            animation: slideInUp 0.3s ease;
        }
        
        @keyframes slideInUp {
            from { transform: translate(-50%, 20px); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
        }
        
        .voice-status.recording {
            background-color: var(--danger-color);
            animation: pulse 1.5s infinite;
        }
        
        .error-message {
            color: var(--danger-color);
            margin-top: 0.5rem;
            font-size: 0.8rem;
        }
    </style>
</head>
<body data-theme="<?php echo $currentTheme; ?>">
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <i class="fas fa-robot"></i>
                    V-Friend
                </div>
                
                <button class="nav-toggle" id="navToggle">
                    <i class="fas fa-bars"></i>
                </button>
                
                <nav id="navMenu">
                    <ul>
                        <li><a href="#" onclick="showSection('chat')"><i class="fas fa-comments"></i> چت</a></li>
                        <li><a href="#" onclick="showSection('profile')"><i class="fas fa-user"></i> پروفایل</a></li>
                        <li><a href="#" onclick="showSection('settings')"><i class="fas fa-cog"></i> تنظیمات</a></li>
                        <li><a href="#" onclick="showSection('about')"><i class="fas fa-info-circle"></i> درباره ما</a></li>
                        <li><a href="#" onclick="showSection('support')"><i class="fas fa-headset"></i> پشتیبانی</a></li>
                    </ul>
                </nav>
                
                <button class="theme-toggle" onclick="toggleTheme()">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
        </div>
    </header>

    <div class="container">
        <!-- بخش نقل قول انگیزشی -->
        <div class="quote-section">
            <p id="motivational-quote"><i class="fas fa-quote-left"></i> <?php echo $quoteText; ?> <i class="fas fa-quote-right"></i></p>
        </div>
        
        <!-- بخش چت (پیش‌فرض) -->
        <div id="chat-section" class="main-content">
            <?php if (isset($_SESSION['needs_registration'])): ?>
                <!-- صفحه ثبت‌نام -->
                <div class="profile-section">
                    <h2><i class="fas fa-user-plus"></i> ثبت‌نام در V-Friend</h2>
                    <?php if (isset($_SESSION['register_error'])): ?>
                        <div class="error-message"><?php echo $_SESSION['register_error']; unset($_SESSION['register_error']); ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="register">
                        <div class="form-group">
                            <label for="name">نام شما:</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-play"></i> شروع گفتگو</button>
                    </form>
                </div>
            <?php elseif (!$rulesAccepted): ?>
                <!-- صفحه قوانین -->
                <div class="rules-section">
                    <h2><i class="fas fa-exclamation-circle"></i> قوانین استفاده از V-Friend</h2>
                    <div>
                        <p>لطفاً قبل از استفاده از برنامه، قوانین زیر را مطالعه و تأیید کنید:</p>
                        <ol>
                            <li>احترام متقابل را در گفتگو رعایت کنید.</li>
                            <li>از ارسال محتوای توهین‌آمیز یا نامناسب خودداری کنید.</li>
                            <li>مکالمات شما محرمانه می‌ماند اما برای بهبود سیستم تحلیل می‌شوند.</li>
                            <li>این برنامه جایگزین مشاوره تخصصی روانشناسی نیست.</li>
                            <li>در صورت مشاهده هرگونه مشکل، با پشتیبانی تماس بگیرید.</li>
                        </ol>
                        <p>متن کامل قوانین در <a href="https://arsham-kurddev.ir/V-friend/Rules" target="_blank">این لینک</a> قابل مشاهده است.</p>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="accept_rules">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> موافقم و ادامه می‌دهم</button>
                    </form>
                </div>
            <?php else: ?>
                <!-- جستجو در پیام‌ها -->
                <div class="search-section">
                    <div class="search-box">
                        <input type="text" id="search-input" placeholder="جستجو در پیام‌ها...">
                        <button onclick="searchMessages()"><i class="fas fa-search"></i> جستجو</button>
                    </div>
                </div>
                
                <!-- بخش چت اصلی -->
                <div class="chat-section" id="chat-messages">
                    <?php if (!empty($messages)): ?>
                        <?php foreach ($messages as $message): ?>
                            <?php if ($message['sender'] === 'user'): ?>
                                <div class="message user-message" id="message-<?php echo $message['id']; ?>">
                                    <div class="message-sender">شما:</div>
                                    <p><?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <div class="message-actions">
                                        <button onclick="copyText('<?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?>')"><i class="fas fa-copy"></i> کپی</button>
                                        <button onclick="deleteMessageWithAnimation('<?php echo $message['id']; ?>')"><i class="fas fa-trash"></i> حذف</button>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="message bot-message" id="message-<?php echo $message['id']; ?>">
                                    <div class="message-sender">نورا:</div>
                                    <p><?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <div class="message-actions">
                                        <button onclick="copyText('<?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?>')"><i class="fas fa-copy"></i> کپی</button>
                                        <button class="tts-button" onclick="speakText('<?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?>', this)"><i class="fas fa-volume-up"></i> پخش</button>
                                        <button class="share-button" onclick="shareMessage('<?php echo htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo isset($prevMessage) && $prevMessage['sender'] === 'user' ? htmlspecialchars($prevMessage['text'], ENT_QUOTES, 'UTF-8') : ''; ?>')"><i class="fas fa-share-alt"></i> اشتراک</button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php $prevMessage = $message; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="message bot-message">
                            <div class="message-sender">نورا:</div>
                            <p>سلام <?php echo htmlspecialchars($_SESSION['user_name'], ENT_QUOTES, 'UTF-8'); ?>! من نورا هستم، دوست صمیمی و همراه تو! 😊</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- انتخاب حالت گفتگو -->
                <div class="mode-selector">
                    <button class="mode-button active" data-mode="normal" onclick="setMode('normal')">
                        <i class="fas fa-comment"></i> عادی
                    </button>
                    <button class="mode-button disabled" data-mode="listen" onclick="showComingSoon()">
                        <i class="fas fa-headphones"></i> گوش کردن <small>(به زودی)</small>
                    </button>
                    <button class="mode-button" data-mode="analysis" onclick="setMode('analysis')">
                        <i class="fas fa-brain"></i> تحلیل احساسات
                    </button>
                    <button class="mode-button" data-mode="focus" onclick="setMode('focus')">
                        <i class="fas fa-target"></i> تمرکز
                    </button>
                </div>
                
                <!-- ورود پیام -->
                <form method="POST" id="message-form">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="action" value="send_message">
                    <input type="hidden" id="mode" name="mode" value="normal">
                    <div class="input-section">
                        <button type="button" class="voice-record-btn" id="voice-record-btn" title="ضبط صوتی">
                            <i class="fas fa-microphone"></i>
                        </button>
                        <input type="text" name="message_text" id="message-text" placeholder="پیام خود را بنویسید..." required>
                        <button type="submit"><i class="fas fa-paper-plane"></i> ارسال</button>
                    </div>
                </form>
                
                <!-- دکمه‌های اقدام -->
                <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
                    <button class="btn btn-danger" onclick="confirmDeleteAll()">
                        <i class="fas fa-trash"></i> حذف همه گفتگوها
                    </button>
                    <button class="btn btn-success coming-soon" onclick="showComingSoon()">
                        <i class="fas fa-sync"></i> نقل قول جدید
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- بخش پروفایل -->
        <div id="profile-section" class="main-content hidden">
            <div class="profile-section">
                <h2><i class="fas fa-user-edit"></i> ویرایش پروفایل</h2>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="action" value="save_profile">
                    <div class="form-group">
                        <label for="profile-name">نام:</label>
                        <input type="text" id="profile-name" name="name" value="<?php echo htmlspecialchars($_SESSION['user_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="age">سن:</label>
                        <input type="number" id="age" name="age" min="10" max="100" value="<?php echo htmlspecialchars($_SESSION['age'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="about">درباره من:</label>
                        <textarea id="about" name="about" rows="3"><?php echo htmlspecialchars($_SESSION['about'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="interests">علایق:</label>
                        <input type="text" id="interests" name="interests" value="<?php echo htmlspecialchars($_SESSION['interests'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="favorite_color">رنگ مورد علاقه:</label>
                        <select id="favorite_color" name="favorite_color">
                            <option value="purple" <?php echo ($_SESSION['favorite_color'] ?? '') == 'purple' ? 'selected' : ''; ?>>بنفش</option>
                            <option value="blue" <?php echo ($_SESSION['favorite_color'] ?? '') == 'blue' ? 'selected' : ''; ?>>آبی</option>
                            <option value="green" <?php echo ($_SESSION['favorite_color'] ?? '') == 'green' ? 'selected' : ''; ?>>سبز</option>
                            <option value="red" <?php echo ($_SESSION['favorite_color'] ?? '') == 'red' ? 'selected' : ''; ?>>قرمز</option>
                            <option value="orange" <?php echo ($_SESSION['favorite_color'] ?? '') == 'orange' ? 'selected' : ''; ?>>نارنجی</option>
                            <option value="pink" <?php echo ($_SESSION['favorite_color'] ?? '') == 'pink' ? 'selected' : ''; ?>>صورتی</option>
                            <option value="teal" <?php echo ($_SESSION['favorite_color'] ?? '') == 'teal' ? 'selected' : ''; ?>>فیروزه‌ای</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="personality">شخصیت:</label>
                        <select id="personality" name="personality">
                            <option value="introvert" <?php echo ($_SESSION['personality'] ?? '') == 'introvert' ? 'selected' : ''; ?>>درون‌گرا</option>
                            <option value="extrovert" <?php echo ($_SESSION['personality'] ?? '') == 'extrovert' ? 'selected' : ''; ?>>برون‌گرا</option>
                            <option value="ambivert" <?php echo ($_SESSION['personality'] ?? '') == 'ambivert' ? 'selected' : ''; ?>>بینابین</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ذخیره تغییرات</button>
                </form>
            </div>
        </div>
        
        <!-- بخش تنظیمات -->
        <div id="settings-section" class="main-content hidden">
            <div class="settings-panel">
                <h2 class="settings-title"><i class="fas fa-paint-brush"></i> تنظیمات ظاهری</h2>
                
                <div class="form-group">
                    <label>تم:</label>
                    <div class="theme-options">
                        <div class="theme-option <?php echo $currentTheme === 'light' ? 'active' : ''; ?>" onclick="changeTheme('light')">
                            <i class="fas fa-sun"></i> روز
                        </div>
                        <div class="theme-option <?php echo $currentTheme === 'dark' ? 'active' : ''; ?>" onclick="changeTheme('dark')">
                            <i class="fas fa-moon"></i> شب
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>رنگ‌بندی:</label>
                    <div class="color-options">
                        <div class="color-option purple <?php echo $currentColorScheme === 'purple' ? 'active' : ''; ?>" onclick="changeColorScheme('purple')" title="بنفش"></div>
                        <div class="color-option blue <?php echo $currentColorScheme === 'blue' ? 'active' : ''; ?>" onclick="changeColorScheme('blue')" title="آبی"></div>
                        <div class="color-option green <?php echo $currentColorScheme === 'green' ? 'active' : ''; ?>" onclick="changeColorScheme('green')" title="سبز"></div>
                        <div class="color-option red <?php echo $currentColorScheme === 'red' ? 'active' : ''; ?>" onclick="changeColorScheme('red')" title="قرمز"></div>
                        <div class="color-option orange <?php echo $currentColorScheme === 'orange' ? 'active' : ''; ?>" onclick="changeColorScheme('orange')" title="نارنجی"></div>
                        <div class="color-option pink <?php echo $currentColorScheme === 'pink' ? 'active' : ''; ?>" onclick="changeColorScheme('pink')" title="صورتی"></div>
                        <div class="color-option teal <?php echo $currentColorScheme === 'teal' ? 'active' : ''; ?>" onclick="changeColorScheme('teal')" title="فیروزه‌ای"></div>
                    </div>
                </div>
            </div>
            
            <div class="settings-panel">
                <h2 class="settings-title"><i class="fas fa-database"></i> مدیریت داده‌ها</h2>
                <p>در این بخش می‌توانید داده‌های خود را مدیریت کنید.</p>
                <button class="btn btn-danger" onclick="confirmDeleteAll()">
                    <i class="fas fa-trash"></i> حذف همه گفتگوها
                </button>
                <button class="btn btn-primary coming-soon" onclick="showComingSoon()">
                    <i class="fas fa-download"></i> خروجی از گفتگوها
                </button>
            </div>
        </div>
        
        <!-- بخش درباره ما -->
        <div id="about-section" class="main-content hidden">
            <div class="about-section">
                <h2><i class="fas fa-link"></i> لینک‌های مرتبط</h2>
                
                <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1.5rem;">
                    <a href="https://arsham-kurddev.ir/V-friend" target="_blank" class="btn btn-primary">
                        <i class="fas fa-globe"></i> وبسایت رسمی
                    </a>
                    
                    <a href="https://rubika.ir/V_Friend" target="_blank" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> کانال روبیکا
                    </a>
                    
                    <a href="https://arsham-kurddev.ir/V-friend/question" target="_blank" class="btn btn-primary">
                        <i class="fas fa-question-circle"></i> سوالات متداول
                    </a>
                    
                    <button class="btn btn-primary coming-soon" onclick="showComingSoon()">
                        <i class="fas fa-bolt"></i> حالت آنلاین
                    </button>
                </div>
            </div>
        </div>
        
        <!-- بخش پشتیبانی -->
        <div id="support-section" class="main-content hidden">
            <div class="support-section">
                <h2><i class="fas fa-headset"></i> پشتیبانی و ارتباط با ما</h2>
                
                <div style="margin-top: 1.5rem;">
                    <a href="https://goftino.com/c/2AR49a" target="_blank" class="btn btn-success">
                        <i class="fas fa-comments"></i> ارتباط با پشتیبانی
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>© 2023 V-Friend - تمام حقوق محفوظ است</p>
        </div>
    </footer>
    
    <!-- مودال تایید حذف همه گفتگوها -->
    <div class="modal" id="delete-confirm-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle"></i> تایید حذف</h3>
                <button class="close-modal" onclick="closeModal('delete-confirm-modal')">&times;</button>
            </div>
            <p>آیا مطمئن هستید که می‌خواهید همه گفتگوهای خود را حذف کنید؟ این عمل غیرقابل بازگشت است.</p>
            <div style="display: flex; gap: 0.5rem; justify-content: flex-end; margin-top: 1.5rem;">
                <button class="btn" onclick="closeModal('delete-confirm-modal')">لغو</button>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="action" value="delete_all">
                    <button type="submit" class="btn btn-danger">حذف همه</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال اشتراک‌گذاری -->
    <div class="modal" id="share-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-share-alt"></i> اشتراک‌گذاری گفتگو</h3>
                <button class="close-modal" onclick="closeModal('share-modal')">&times;</button>
            </div>
            <div id="screenshot-preview" class="screenshot-container">
                <div class="screenshot-logo">V-Friend</div>
                <div class="screenshot-message screenshot-user">
                    <div class="message-sender">شما</div>
                    <span id="screenshot-user-text"></span>
                </div>
                <div class="screenshot-message screenshot-bot">
                    <div class="message-sender">نورا</div>
                    <span id="screenshot-bot-text"></span>
                </div>
                <div class="screenshot-watermark">arsham-kurddev.ir/V-friend</div>
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <button id="download-screenshot" class="btn btn-primary">
                    <i class="fas fa-download"></i> ذخیره تصویر
                </button>
            </div>
        </div>
    </div>
    
    <!-- وضعیت ضبط صدا -->
    <div class="voice-status" id="voice-status">
        <i class="fas fa-microphone"></i>
        <span id="voice-status-text">در حال گوش دادن...</span>
    </div>
    
    <script>
        // مدیریت ناوبری
        document.getElementById('navToggle').addEventListener('click', function() {
            const navMenu = document.querySelector('nav ul');
            navMenu.classList.toggle('show');
        });
        
        function showSection(sectionId) {
            // مخفی کردن همه بخش‌ها
            document.querySelectorAll('.main-content').forEach(section => {
                section.classList.add('hidden');
            });
            
            // نمایش بخش انتخاب شده
            document.getElementById(sectionId + '-section').classList.remove('hidden');
            
            // بستن منوی ناوبری در حالت موبایل
            const navMenu = document.querySelector('nav ul');
            if (navMenu.classList.contains('show')) {
                navMenu.classList.remove('show');
            }
            
            // اسکرول به بالا
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // تغییر تم
        function toggleTheme() {
            const currentTheme = document.body.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            // تغییر آیکون
            const themeIcon = document.querySelector('.theme-toggle i');
            themeIcon.className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
            
            // ارسال درخواست به سرور برای ذخیره ترجیح کاربر
            const formData = new FormData();
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');
            formData.append('action', 'change_theme');
            formData.append('theme', newTheme);
            
            fetch('', {
                method: 'POST',
                body: formData
            }).then(() => {
                // رفرش صفحه برای اعمال تغییرات
                window.location.reload();
            });
        }
        
        // تغییر تم از طریق دکمه‌های انتخاب
        function changeTheme(theme) {
            // ارسال درخواست به سرور برای ذخیره ترجیح کاربر
            const formData = new FormData();
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');
            formData.append('action', 'change_theme');
            formData.append('theme', theme);
            
            fetch('', {
                method: 'POST',
                body: formData
            }).then(() => {
                // رفرش صفحه برای اعمال تغییرات
                window.location.reload();
            });
        }
        
        // تغییر رنگ‌بندی
        function changeColorScheme(color) {
            // ارسال درخواست به سرور برای ذخیره ترجیح کاربر
            const formData = new FormData();
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');
            formData.append('action', 'change_color');
            formData.append('color_scheme', color);
            
            fetch('', {
                method: 'POST',
                body: formData
            }).then(() => {
                // رفرش صفحه برای اعمال تغییرات
                window.location.reload();
            });
        }
        
        // مدیریت مودال‌ها
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        function confirmDeleteAll() {
            openModal('delete-confirm-modal');
        }
        
        // تنظیم حالت گفتگو
        function setMode(mode) {
            document.getElementById('mode').value = mode;
            
            // برجسته کردن دکمه انتخاب شده
            document.querySelectorAll('.mode-button').forEach(button => {
                if (button.getAttribute('data-mode') === mode) {
                    button.classList.add('active');
                } else {
                    button.classList.remove('active');
                }
            });
        }
        
        // کپی متن
        function copyText(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('متن کپی شد!');
            });
        }
        
        // حذف پیام با انیمیشن
        function deleteMessageWithAnimation(messageId) {
            const messageElement = document.getElementById('message-' + messageId);
            
            if (messageElement) {
                messageElement.classList.add('deleting');
            }
            
            // ارسال درخواست حذف به سرور
            const formData = new FormData();
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');
            formData.append('action', 'delete_message');
            formData.append('message_id', messageId);
            
            fetch('', {
                method: 'POST',
                body: formData
            });
            
            // حذف عناصر از DOM پس از انیمیشن
            setTimeout(() => {
                if (messageElement) messageElement.remove();
            }, 300);
        }
        
        // پخش متن با صدای زن (TTS)
        function speakText(text, button) {
            if ('speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = 'fa-IR';
                utterance.rate = 0.9;
                utterance.pitch = 1.1;
                
                // تغییر آیکون هنگام پخش
                const icon = button.querySelector('i');
                const originalClass = icon.className;
                
                utterance.onstart = function() {
                    icon.className = 'fas fa-stop';
                    button.closest('.message').classList.add('tts-playing');
                };
                
                utterance.onend = function() {
                    icon.className = originalClass;
                    button.closest('.message').classList.remove('tts-playing');
                };
                
                utterance.onerror = function() {
                    icon.className = originalClass;
                    button.closest('.message').classList.remove('tts-playing');
                    alert('خطا در پخش صوت. لطفاً مرورگر خود را بروزرسانی کنید.');
                };
                
                speechSynthesis.speak(utterance);
            } else {
                alert('مرورگر شما از قابلیت پخش صوت پشتیبانی نمی‌کند.');
            }
        }
        
        // اشتراک‌گذاری پیام
        function shareMessage(botMessage, userMessage) {
            document.getElementById('screenshot-user-text').textContent = userMessage || 'سلام نورا!';
            document.getElementById('screenshot-bot-text').textContent = botMessage;
            openModal('share-modal');
        }
        
        // ذخیره اسکرین‌شات
        document.getElementById('download-screenshot').addEventListener('click', function() {
            const screenshotElement = document.getElementById('screenshot-preview');
            
            html2canvas(screenshotElement, {
                backgroundColor: '#ffffff',
                scale: 2,
                logging: false
            }).then(canvas => {
                const link = document.createElement('a');
                link.download = 'v-friend-chat.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
            });
        });
        
        // جستجو در پیام‌ها
        function searchMessages() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const messages = document.querySelectorAll('.message');
            
            messages.forEach(message => {
                const messageText = message.textContent.toLowerCase();
                // جستجو فقط در متن پیام، نه در دکمه‌ها
                const messageContent = message.querySelector('p')?.textContent.toLowerCase() || '';
                
                if (messageContent.includes(searchTerm)) {
                    message.style.display = 'flex';
                    message.style.animation = 'pulse 0.5s';
                    // حفظ سایز اصلی عناصر داخلی
                    message.querySelectorAll('.message-actions button').forEach(btn => {
                        btn.style.fontSize = '0.65rem';
                        btn.style.padding = '0.2rem 0.5rem';
                    });
                    setTimeout(() => {
                        message.style.animation = '';
                    }, 500);
                } else {
                    message.style.display = 'none';
                }
            });
        }
        
        // مدیریت ضبط صدا
        let recognition = null;
        let isRecording = false;
        
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'fa-IR';
            
            recognition.onstart = function() {
                isRecording = true;
                document.getElementById('voice-record-btn').classList.add('recording');
                document.getElementById('voice-status').style.display = 'flex';
                document.getElementById('voice-status').classList.add('recording');
                document.getElementById('voice-status-text').textContent = 'در حال ضبط صدا...';
            };
            
            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                document.getElementById('message-text').value = transcript;
            };
            
            recognition.onerror = function(event) {
                console.error('Speech recognition error', event.error);
                document.getElementById('voice-status-text').textContent = 'خطا در تشخیص صدا: ' + event.error;
                setTimeout(() => {
                    document.getElementById('voice-status').style.display = 'none';
                }, 3000);
            };
            
            recognition.onend = function() {
                isRecording = false;
                document.getElementById('voice-record-btn').classList.remove('recording');
                document.getElementById('voice-status').classList.remove('recording');
                document.getElementById('voice-status-text').textContent = 'پردازش صدا...';
                
                setTimeout(() => {
                    document.getElementById('voice-status').style.display = 'none';
                }, 1000);
            };
        }
        
        document.getElementById('voice-record-btn').addEventListener('click', function() {
            if (recognition) {
                if (!isRecording) {
                    recognition.start();
                } else {
                    recognition.stop();
                }
            } else {
                alert('مرورگر شما از تشخیص صدا پشتیبانی نمی‌کند.');
            }
        });
        
        // مدیریت نمایش/پنهان کردن دکمه ضبط صدا بر اساس محتوای فیلد
        document.getElementById('message-text').addEventListener('input', function() {
            if (this.value.trim() !== '') {
                document.getElementById('voice-record-btn').style.display = 'none';
            } else {
                document.getElementById('voice-record-btn').style.display = 'flex';
            }
        });
        
        // نمایش پیام "به زودی"
        function showComingSoon() {
            alert('این ویژگی به زودی اضافه خواهد شد!');
        }
        
        // اسکرول به پایین چت
        function scrollToBottom() {
            const chatMessages = document.getElementById('chat-messages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }
        
        // اسکرول به پایین هنگام بارگذاری صفحه
        window.addEventListener('load', function() {
            scrollToBottom();
            // نمایش تدریجی صفحه
            document.body.style.opacity = 1;
        });
        
        // جلوگیری از ارسال فرم با клаید Enter در فیلد جستجو
        document.getElementById('search-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchMessages();
            }
        });
    </script>
</body>
</html>