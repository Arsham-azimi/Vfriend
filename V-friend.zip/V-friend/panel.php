<?php
// ابتدا تنظیمات session را قبل از شروع session اعمال کنیم
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0);

session_start();
header('Content-Type: text/html; charset=utf-8');

// بررسی دسترسی ادمین
define('ADMIN_USERNAME', 'arsham');
define('ADMIN_PASSWORD', 'arsham');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
        if ($_POST['username'] === ADMIN_USERNAME && $_POST['password'] === ADMIN_PASSWORD) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_login_time'] = time();
            $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } else {
            $login_error = "نام کاربری یا رمز عبور اشتباه است.";
        }
    }
    
    // نمایش صفحه لاگین
    echo '<!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ورود به پنل مدیریت V-Friend</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn/500.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Vazirmatn", sans-serif; }
            body { background-color: #f8f9fa; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 1rem; }
            .login-container { background-color: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
            .login-header { text-align: center; margin-bottom: 2rem; }
            .login-header h2 { color: #2c3e50; margin-bottom: 0.5rem; }
            .login-header p { color: #7f8c8d; }
            .form-group { margin-bottom: 1.5rem; }
            .form-group label { display: block; margin-bottom: 0.5rem; color: #2c3e50; font-weight: 500; }
            .form-group input { width: 100%; padding: 0.8rem 1rem; border: 1px solid #ddd; border-radius: 4px; font-size: 1rem; }
            .form-group input:focus { outline: none; border-color: #3498db; box-shadow: 0 0 0 3px rgba(52,152,219,0.2); }
            .btn { width: 100%; padding: 0.8rem; background-color: #3498db; color: white; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 0.5rem; }
            .btn:hover { background-color: #2980b9; }
            .error-message { background-color: #f8d7da; color: #721c24; padding: 0.8rem; border-radius: 4px; margin-bottom: 1rem; text-align: center; }
            @media (max-width: 480px) {
                .login-container { padding: 1.5rem; }
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="login-header">
                <h2><i class="fas fa-cogs"></i> پنل مدیریت V-Friend</h2>
                <p>لطفاً برای ادامه وارد شوید</p>
            </div>
            '. (isset($login_error) ? '<div class="error-message">'.$login_error.'</div>' : '') .'
            <form method="POST">
                <div class="form-group">
                    <label for="username">نام کاربری:</label>
                    <input type="text" id="username" name="username" required value="arsham">
                </div>
                <div class="form-group">
                    <label for="password">رمز عبور:</label>
                    <input type="password" id="password" name="password" required value="arsham">
                </div>
                <button type="submit" class="btn"><i class="fas fa-sign-in-alt"></i> ورود به سیستم</button>
            </form>
        </div>
    </body>
    </html>';
    exit();
}

// تولید CSRF Token اگر وجود ندارد
if (empty($_SESSION['admin_csrf_token'])) {
    $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
}

// اعتبارسنجی CSRF Token برای درخواست‌های POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token'])) {
    if ($_POST['csrf_token'] !== $_SESSION['admin_csrf_token']) {
        die('درخواست نامعتبر است');
    }
}

// توابع مدیریتی
function getAllUsers() {
    $dataFile = 'data.json';
    $users = [];
    
    if (file_exists($dataFile)) {
        $jsonData = file_get_contents($dataFile);
        $users = json_decode($jsonData, true);
        if (!is_array($users)) $users = [];
    }
    
    // حذف کاربران تکراری - فقط کاربران با کلیدهای معتبر (نه کلیدهای عددی)
    $filteredUsers = [];
    foreach ($users as $id => $userData) {
        // فقط کاربرانی که کلید آنها معتبر است (نه عددی) را نگه دارید
        if (!is_numeric($id) && isset($userData['name'])) {
            $filteredUsers[$id] = $userData;
        }
    }
    
    return $filteredUsers;
}

function getAllConversations() {
    $dataFile = 'conversations.json';
    $conversations = [];
    
    if (file_exists($dataFile)) {
        $jsonData = file_get_contents($dataFile);
        $conversations = json_decode($jsonData, true);
        if (!is_array($conversations)) $conversations = [];
    }
    
    return $conversations;
}

function getUserMessages($userId) {
    $conversations = getAllConversations();
    $userMessages = [];
    
    foreach ($conversations as $message) {
        if (isset($message['id']) && $message['id'] === $userId) {
            $userMessages[] = $message;
        }
    }
    
    return $userMessages;
}

function banUser($userId, $status, $reason = '') {
    $dataFile = 'data.json';
    $data = getAllUsers();
    
    if (isset($data[$userId])) {
        $data[$userId]['ban'] = (bool)$status;
        $data[$userId]['ban_date'] = $status ? date('Y-m-d H:i:s') : null;
        $data[$userId]['ban_reason'] = $status ? $reason : '';
        $data[$userId]['ban_admin'] = $status ? 'admin' : '';
        
        file_put_contents($dataFile, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        // به روزرسانی در API
        $name = $data[$userId]['name'] ?? 'کاربر';
        $url = "https://arsham-kurddev.ir/V-friend/user.php?name=" . urlencode($name) . "&ban=" . ($status ? 'true' : 'false') . "&id=" . urlencode($userId);
        $context = stream_context_create([
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
            'http' => ['timeout' => 10, 'header' => "User-Agent: V-Friend-App\r\n"]
        ]);
        @file_get_contents($url, false, $context);
        
        return true;
    }
    
    return false;
}

function deleteUserMessages($userId) {
    $conversations = getAllConversations();
    $newConversations = [];
    
    foreach ($conversations as $message) {
        if (!(isset($message['id']) && $message['id'] === $userId)) {
            $newConversations[] = $message;
        }
    }
    
    file_put_contents('conversations.json', json_encode($newConversations, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    // حذف از API
    $url = "https://www.arsham-kurddev.ir/V-friend/delete.php?id=" . urlencode($userId);
    $context = stream_context_create([
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
        'http' => ['timeout' => 10, 'header' => "User-Agent: V-Friend-App\r\n"]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function deleteConversation($messageId) {
    $conversations = getAllConversations();
    $newConversations = [];
    
    foreach ($conversations as $message) {
        if (!(isset($message['id_m']) && $message['id_m'] === $messageId)) {
            $newConversations[] = $message;
        }
    }
    
    file_put_contents('conversations.json', json_encode($newConversations, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    // حذف از API
    $url = "https://www.arsham-kurddev.ir/V-friend/delete_masege.php?id_m=" . urlencode($messageId);
    $context = stream_context_create([
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
        'http' => ['timeout' => 10, 'header' => "User-Agent: V-Friend-App\r\n"]
    ]);
    $response = @file_get_contents($url, false, $context);
    return json_decode($response, true);
}

function getSystemStats() {
    $users = getAllUsers();
    $conversations = getAllConversations();
    
    $totalUsers = is_array($users) ? count($users) : 0;
    $bannedUsers = 0;
    $activeUsers = 0;
    $totalMessages = is_array($conversations) ? count($conversations) : 0;
    
    $messagesPerUser = [];
    if (is_array($conversations)) {
        foreach ($conversations as $message) {
            if (isset($message['id'])) {
                $userId = $message['id'];
                if (!isset($messagesPerUser[$userId])) {
                    $messagesPerUser[$userId] = 0;
                }
                $messagesPerUser[$userId]++;
            }
        }
    }
    
    $mostActiveUser = null;
    $maxMessages = 0;
    foreach ($messagesPerUser as $userId => $count) {
        if ($count > $maxMessages) {
            $maxMessages = $count;
            $mostActiveUser = $userId;
        }
    }
    
    if (is_array($users)) {
        foreach ($users as $user) {
            if ($user['ban'] ?? false) {
                $bannedUsers++;
            } else {
                $activeUsers++;
            }
        }
    }
    
    // آمار روزانه
    $dailyStats = [];
    if (is_array($conversations)) {
        foreach ($conversations as $message) {
            if (isset($message['id_m'])) {
                // استفاده از timestamp فعلی اگر id_m معتبر نیست
                $timestamp = is_numeric(substr($message['id_m'], 0, 10)) ? substr($message['id_m'], 0, 10) : time();
                $date = date('Y-m-d', $timestamp);
                if (!isset($dailyStats[$date])) {
                    $dailyStats[$date] = 0;
                }
                $dailyStats[$date]++;
            }
        }
    }
    
    ksort($dailyStats);
    $last7Days = array_slice($dailyStats, -7, 7, true);
    
    return [
        'total_users' => $totalUsers,
        'active_users' => $activeUsers,
        'banned_users' => $bannedUsers,
        'total_messages' => $totalMessages,
        'most_active_user' => $mostActiveUser,
        'max_messages' => $maxMessages,
        'daily_stats' => $last7Days
    ];
}

function sendBroadcastMessage($message) {
    $url = "https://arsham-kurddev.ir/V-friend/all.php?text=" . urlencode($message);
    $context = stream_context_create([
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
        'http' => ['timeout' => 10, 'header' => "User-Agent: V-Friend-App\r\n"]
    ]);
    $response = @file_get_contents($url, false, $context);
    return $response;
}

function getServerStatus() {
    return ['status' => 'online', 'message' => 'سرویس فعال است'];
}

// پردازش اقدامات مدیریتی
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'ban_user':
            if (isset($_POST['user_id']) && isset($_POST['ban_status'])) {
                $reason = $_POST['ban_reason'] ?? 'بدون دلیل';
                $result = banUser($_POST['user_id'], $_POST['ban_status'], $reason);
                $_SESSION['admin_message'] = $result ? 
                    "وضعیت کاربر با موفقیت به روز شد." : 
                    "خطا در به روزرسانی وضعیت کاربر.";
            }
            break;
            
        case 'delete_user_messages':
            if (isset($_POST['user_id'])) {
                $result = deleteUserMessages($_POST['user_id']);
                $_SESSION['admin_message'] = "همه پیام‌های کاربر حذف شدند.";
            }
            break;
            
        case 'delete_conversation':
            if (isset($_POST['message_id'])) {
                $result = deleteConversation($_POST['message_id']);
                $_SESSION['admin_message'] = "مکالمه حذف شد.";
            }
            break;
            
        case 'export_data':
            $type = $_POST['export_type'] ?? 'users';
            $data = [];
            
            if ($type === 'users') {
                $data = getAllUsers();
                header('Content-Type: application/json');
                header('Content-Disposition: attachment; filename="users_export_' . date('Y-m-d') . '.json"');
                echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
                exit();
            } elseif ($type === 'conversations') {
                $data = getAllConversations();
                header('Content-Type: application/json');
                header('Content-Disposition: attachment; filename="conversations_export_' . date('Y-m-d') . '.json"');
                echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
                exit();
            }
            break;
            
        case 'broadcast_message':
            if (isset($_POST['broadcast_text']) && !empty($_POST['broadcast_text'])) {
                $result = sendBroadcastMessage($_POST['broadcast_text']);
                $_SESSION['admin_message'] = "پیام همگانی ارسال شد: " . $result;
            }
            break;
            
        case 'logout':
            session_destroy();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
            break;
    }
    
    // جلوگیری از ارسال مجدد فرم با رفرش صفحه
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// دریافت تمام کاربران
$users = getAllUsers();
if (!is_array($users)) $users = [];

// جستجوی کاربران
$searchTerm = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = trim($_GET['search']);
    $filteredUsers = [];
    
    foreach ($users as $id => $userData) {
        if (stripos($userData['name'] ?? '', $searchTerm) !== false || 
            stripos($id, $searchTerm) !== false ||
            (isset($userData['created_at']) && stripos($userData['created_at'], $searchTerm) !== false) ||
            (isset($userData['ban_reason']) && stripos($userData['ban_reason'], $searchTerm) !== false)) {
            $filteredUsers[$id] = $userData;
        }
    }
    
    $users = $filteredUsers;
}

// دریافت پیام‌های کاربر انتخاب شده
$selectedUser = null;
$userMessages = [];
if (isset($_GET['view_user']) && !empty($_GET['view_user'])) {
    $userId = $_GET['view_user'];
    if (isset($users[$userId])) {
        $selectedUser = $users[$userId];
        $selectedUser['id'] = $userId;
        $userMessages = getUserMessages($userId);
        if (!is_array($userMessages)) $userMessages = [];
    }
}

// دریافت آمار سیستم
$stats = getSystemStats();

// دریافت وضعیت سرور
$serverStatus = getServerStatus();

// مرتب‌سازی کاربران بر اساس تاریخ ایجاد (جدیدترین اول)
uasort($users, function($a, $b) {
    $dateA = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
    $dateB = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
    return $dateB - $dateA;
});

// تنظیمات صفحه‌بندی
$usersPerPage = 10;
$totalPages = ceil(count($users) / $usersPerPage);
$currentPage = isset($_GET['page']) ? max(1, min($totalPages, intval($_GET['page']))) : 1;
$startIndex = ($currentPage - 1) * $usersPerPage;
$paginatedUsers = array_slice($users, $startIndex, $usersPerPage, true);

// خروجی HTML پنل مدیریت
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت V-Friend</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn/500.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --text-color: #2c3e50;
            --bg-color: #f8f9fa;
            --card-bg: #ffffff;
            --border-radius: 8px;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Vazirmatn', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
            background-color: var(--dark-color);
            color: white;
            padding: 1rem;
        }

        .sidebar-header {
            padding: 1rem 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar-header h2 {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.2rem;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .sidebar-nav ul {
            list-style: none;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .sidebar-nav li {
            margin-bottom: 0;
        }

        .sidebar-nav a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem;
            border-radius: var(--border-radius);
            transition: var(--transition);
            font-size: 0.9rem;
        }

        .sidebar-nav a:hover, 
        .sidebar-nav a.active {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .main-content {
            flex: 1;
            padding: 1.5rem;
        }

        .header {
            background-color: var(--card-bg);
            padding: 1rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .server-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            background-color: <?php echo $serverStatus['status'] === 'online' ? 'var(--success-color)' : 'var(--danger-color)'; ?>;
            color: white;
            font-size: 0.9rem;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background-color: var(--card-bg);
            padding: 1rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 100px;
        }

        .stat-card h3 {
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            color: #7f8c8d;
        }

        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            line-height: 1.2;
        }

        .stat-card.total-users { border-top: 4px solid var(--primary-color); }
        .stat-card.active-users { border-top: 4px solid var(--success-color); }
        .stat-card.banned-users { border-top: 4px solid var(--danger-color); }
        .stat-card.total-messages { border-top: 4px solid var(--warning-color); }

        .search-box {
            background-color: var(--card-bg);
            padding: 1rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .search-form {
            display: flex;
            gap: 0.5rem;
            width: 100%;
        }

        .search-form input {
            flex: 1;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
            min-width: 0;
        }

        .search-form button {
            padding: 0.8rem 1.2rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            white-space: nowrap;
        }

        .users-table {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            margin-bottom: 1.5rem;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        th, td {
            padding: 0.8rem;
            text-align: right;
            border-bottom: 1px solid #eee;
            font-size: 0.9rem;
        }

        th {
            background-color: #f8f9fa;
            font-weight: bold;
            white-space: nowrap;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        .btn {
            padding: 0.5rem 0.8rem;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            transition: var(--transition);
            white-space: nowrap;
        }

        .btn-sm {
            padding: 0.3rem 0.6rem;
            font-size: 0.75rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }

        .btn-success {
            background-color: var(--success-color);
            color: white;
        }

        .btn-warning {
            background-color: var(--warning-color);
            color: white;
        }

        .btn-info {
            background-color: #17a2b8;
            color: white;
        }

        .user-details {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            margin-bottom: 1.5rem;
            overflow-x: auto;
        }

        .user-details-header {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }

        .user-info {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            align-items: center;
            justify-content: space-between;
        }

        .user-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .messages-container {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .conversation-item {
            margin-bottom: 1.5rem;
            border: 1px solid #eee;
            border-radius: var(--border-radius);
            overflow: hidden;
        }

        .conversation-header {
            background-color: #f8f9fa;
            padding: 0.5rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
        }

        .conversation-body {
            padding: 1rem;
        }

        .message {
            padding: 0.8rem;
            border-radius: var(--border-radius);
            margin-bottom: 0.8rem;
            position: relative;
        }

        .user-message {
            background-color: #e3f2fd;
            border-right: 4px solid var(--primary-color);
        }

        .bot-message {
            background-color: #f1f8e9;
            border-right: 4px solid var(--success-color);
        }

        .message-sender {
            font-weight: bold;
            margin-bottom: 0.3rem;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .close-alert {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 1.5rem;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .pagination button {
            padding: 0.5rem 0.8rem;
            border: 1px solid #ddd;
            background-color: white;
            border-radius: var(--border-radius);
            cursor: pointer;
            min-width: 40px;
        }

        .pagination button.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 1rem;
        }

        .modal-content {
            background-color: var(--card-bg);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            max-width: 500px;
            width: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            margin-top: 1.5rem;
            flex-wrap: wrap;
        }

        .chart-container {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .export-options {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .export-buttons {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }

        .broadcast-section {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            min-height: 100px;
            resize: vertical;
        }

        @media (min-width: 768px) {
            .admin-container {
                flex-direction: row;
            }
            
            .sidebar {
                width: 250px;
                position: fixed;
                height: 100vh;
                overflow-y: auto;
            }
            
            .main-content {
                margin-right: 0;
                margin-left: 250px;
                width: calc(100% - 250px);
            }
            
            .sidebar-nav ul {
                flex-direction: column;
                gap: 0;
            }
            
            .sidebar-nav li {
                margin-bottom: 0.5rem;
            }
            
            .header {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
            }
            
            .stats-container {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .search-form {
                flex-direction: row;
            }
            
            .user-info {
                flex-direction: row;
            }
        }

        @media (max-width: 767px) {
            .menu-toggle {
                display: block;
            }
            
            .sidebar-nav {
                display: none;
            }
            
            .sidebar-nav.show {
                display: block;
            }
            
            .header-top {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .user-info {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .user-actions {
                justify-content: center;
                width: 100%;
            }
            
            .user-actions .btn {
                flex: 1;
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 1rem;
            }
            
            .stat-card {
                padding: 0.8rem;
            }
            
            .stat-card .stat-value {
                font-size: 1.2rem;
            }
            
            .btn {
                padding: 0.4rem 0.6rem;
                font-size: 0.7rem;
            }
            
            th, td {
                padding: 0.6rem;
            }
            
            .conversation-header {
                flex-direction: column;
                gap: 0.5rem;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- نوار کناری -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-cogs"></i> پنل مدیریت</h2>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav" id="sidebarNav">
                <ul>
                    <li><a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="active"><i class="fas fa-home"></i> پیشخوان</a></li>
                    <li><a href="#users-section"><i class="fas fa-users"></i> مدیریت کاربران</a></li>
                    <li><a href="#broadcast-section"><i class="fas fa-bullhorn"></i> پیام همگانی</a></li>
                    <li><a href="#export-section"><i class="fas fa-download"></i> خروجی داده‌ها</a></li>
                    <li>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                            <input type="hidden" name="action" value="logout">
                            <button type="submit" style="background: none; border: none; color: white; width: 100%; text-align: right; cursor: pointer; display: flex; align-items: center; gap: 0.5rem; padding: 0.8rem;">
                                <i class="fas fa-sign-out-alt"></i> خروج
                            </button>
                        </form>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- محتوای اصلی -->
        <div class="main-content">
            <div class="header">
                <div class="header-top">
                    <h1>مدیریت V-Friend</h1>
                    <div class="server-status">
                        <i class="fas fa-server"></i>
                        <span><?php echo $serverStatus['message']; ?></span>
                    </div>
                </div>
                <div>
                    <span>خوش آمدید، مدیر سیستم | <?php echo date('Y-m-d H:i:s'); ?></span>
                </div>
            </div>
            
            <!-- نمایش پیام‌ها -->
            <?php if (isset($_SESSION['admin_message'])): ?>
                <div class="alert alert-success">
                    <span><?php echo $_SESSION['admin_message']; unset($_SESSION['admin_message']); ?></span>
                    <button class="close-alert">&times;</button>
                </div>
            <?php endif; ?>
            
            <!-- آمار کلی -->
            <div class="stats-container">
                <div class="stat-card total-users">
                    <h3>تعداد کل کاربران</h3>
                    <div class="stat-value"><?php echo $stats['total_users']; ?></div>
                </div>
                
                <div class="stat-card active-users">
                    <h3>کاربران فعال</h3>
                    <div class="stat-value"><?php echo $stats['active_users']; ?></div>
                </div>
                
                <div class="stat-card banned-users">
                    <h3>کاربران مسدود شده</h3>
                    <div class="stat-value"><?php echo $stats['banned_users']; ?></div>
                </div>
                
                <div class="stat-card total-messages">
                    <h3>تعداد کل پیام‌ها</h3>
                    <div class="stat-value"><?php echo $stats['total_messages']; ?></div>
                </div>
            </div>
            
            <!-- بخش آمار و نمودارها -->
            <div class="chart-container">
                <h2><i class="fas fa-chart-bar"></i> آمار و نمودارها</h2>
                <canvas id="statsChart" width="400" height="200"></canvas>
            </div>
            
            <!-- بخش پیام همگانی -->
            <div id="broadcast-section" class="broadcast-section">
                <h2><i class="fas fa-bullhorn"></i> ارسال پیام همگانی</h2>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                    <input type="hidden" name="action" value="broadcast_message">
                    
                    <div class="form-group">
                        <label for="broadcast_text">متن پیام همگانی:</label>
                        <textarea id="broadcast_text" name="broadcast_text" placeholder="متن پیامی که می‌خواهید برای همه کاربران ارسال شود..." required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> ارسال پیام همگانی</button>
                </form>
            </div>
            
            <!-- جستجوی کاربران -->
            <div id="users-section" class="search-box">
                <h2><i class="fas fa-search"></i> جستجوی کاربران</h2>
                <form method="GET" class="search-form">
                    <input type="text" name="search" placeholder="جستجو بر اساس نام، شناسه، دلیل مسدودسازی..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button type="submit"><i class="fas fa-search"></i> جستجو</button>
                    <?php if (!empty($searchTerm)): ?>
                        <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-warning">نمایش همه</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- لیست کاربران -->
            <div class="users-table">
                <h2 style="padding: 1rem; margin: 0;">لیست کاربران</h2>
                <table>
                    <thead>
                        <tr>
                            <th>شناسه کاربر</th>
                            <th>نام</th>
                            <th>تاریخ ایجاد</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($paginatedUsers)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 2rem;">هیچ کاربری یافت نشد.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($paginatedUsers as $id => $user): ?>
                                <tr>
                                    <td><code><?php echo $id; ?></code></td>
                                    <td><?php echo htmlspecialchars($user['name'] ?? 'نامشخص'); ?></td>
                                    <td><?php echo isset($user['created_at']) ? $user['created_at'] : 'نامشخص'; ?></td>
                                    <td>
                                        <?php if ($user['ban'] ?? false): ?>
                                            <span style="color: var(--danger-color);">مسدود شده</span>
                                            <?php if (isset($user['ban_reason']) && !empty($user['ban_reason'])): ?>
                                                <br><small>دلیل: <?php echo htmlspecialchars($user['ban_reason']); ?></small>
                                            <?php endif; ?>
                                            <?php if (isset($user['ban_date']) && !empty($user['ban_date'])): ?>
                                                <br><small>تاریخ: <?php echo $user['ban_date']; ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: var(--success-color);">فعال</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="display: flex; flex-wrap: wrap; gap: 0.3rem;">
                                            <a href="?view_user=<?php echo $id; ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> مشاهده</a>
                                            <?php if ($user['ban'] ?? false): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                                                    <input type="hidden" name="action" value="ban_user">
                                                    <input type="hidden" name="user_id" value="<?php echo $id; ?>">
                                                    <input type="hidden" name="ban_status" value="0">
                                                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-check"></i> آزاد کردن</button>
                                                </form>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-danger btn-sm" onclick="openBanModal('<?php echo $id; ?>')"><i class="fas fa-ban"></i> مسدود کردن</button>
                                            <?php endif; ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                                                <input type="hidden" name="action" value="delete_user_messages">
                                                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
                                                <button type="submit" class="btn btn-warning btn-sm" onclick="return confirm('آیا از حذف تمام پیام‌های این کاربر اطمینان دارید؟')"><i class="fas fa-trash"></i> حذف پیام‌ها</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <!-- صفحه‌بندی -->
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?><?php echo !empty($searchTerm) ? '&search=' . urlencode($searchTerm) : ''; ?>">
                            <button class="<?php echo $i == $currentPage ? 'active' : ''; ?>"><?php echo $i; ?></button>
                        </a>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- جزئیات کاربر انتخاب شده -->
            <?php if ($selectedUser): ?>
                <div class="user-details">
                    <div class="user-details-header">
                        <h2>پیام‌های کاربر: <?php echo htmlspecialchars($selectedUser['name'] ?? 'نامشخص'); ?></h2>
                        <div class="user-info">
                            <div>
                                <strong>شناسه:</strong> <code><?php echo $selectedUser['id']; ?></code>
                                <strong>تاریخ ایجاد:</strong> <?php echo $selectedUser['created_at'] ?? 'نامشخص'; ?>
                                <strong>وضعیت:</strong> 
                                <?php if ($selectedUser['ban'] ?? false): ?>
                                    <span style="color: var(--danger-color);">مسدود شده</span>
                                <?php else: ?>
                                    <span style="color: var(--success-color);">فعال</span>
                                <?php endif; ?>
                            </div>
                            <div class="user-actions">
                                <?php if ($selectedUser['ban'] ?? false): ?>
                                    <form method="POST">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                                        <input type="hidden" name="action" value="ban_user">
                                        <input type="hidden" name="user_id" value="<?php echo $selectedUser['id']; ?>">
                                        <input type="hidden" name="ban_status" value="0">
                                        <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> آزاد کردن کاربر</button>
                                    </form>
                                <?php else: ?>
                                    <button type="button" class="btn btn-danger" onclick="openBanModal('<?php echo $selectedUser['id']; ?>')"><i class="fas fa-ban"></i> مسدود کردن کاربر</button>
                                <?php endif; ?>
                                <form method="POST">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                                    <input type="hidden" name="action" value="delete_user_messages">
                                    <input type="hidden" name="user_id" value="<?php echo $selectedUser['id']; ?>">
                                    <button type="submit" class="btn btn-warning" onclick="return confirm('آیا از حذف تمام پیام‌های این کاربر اطمینان دارید؟')"><i class="fas fa-trash"></i> حذف همه پیام‌ها</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="messages-container">
                        <h3>تاریخچه گفتگو (<?php echo count($userMessages); ?> مکالمه)</h3>
                        
                        <?php if (empty($userMessages)): ?>
                            <p style="text-align: center; padding: 2rem; color: #777;">هیچ مکالمه‌ای یافت نشد.</p>
                        <?php else: ?>
                            <?php foreach ($userMessages as $message): ?>
                                <div class="conversation-item">
                                    <div class="conversation-header">
                                        <div>شناسه مکالمه: <?php echo $message['id_m'] ?? 'نامشخص'; ?></div>
                                        <form method="POST">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                                            <input type="hidden" name="action" value="delete_conversation">
                                            <input type="hidden" name="message_id" value="<?php echo $message['id_m'] ?? ''; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('آیا از حذف این مکالمه اطمینان دارید؟')"><i class="fas fa-trash"></i> حذف مکالمه</button>
                                        </form>
                                    </div>
                                    <div class="conversation-body">
                                        <?php if (isset($message['text1']) && !empty($message['text1'])): ?>
                                            <div class="message user-message">
                                                <div class="message-sender">
                                                    <i class="fas fa-user"></i> کاربر:
                                                </div>
                                                <p><?php echo htmlspecialchars($message['text1']); ?></p>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if (isset($message['text']) && !empty($message['text'])): ?>
                                            <div class="message bot-message">
                                                <div class="message-sender">
                                                    <i class="fas fa-robot"></i> ربات:
                                                </div>
                                                <p><?php echo htmlspecialchars($message['text']); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- بخش خروجی داده‌ها -->
            <div id="export-section" class="export-options">
                <h2><i class="fas fa-download"></i> خروجی داده‌ها</h2>
                <p>در این بخش می‌توانید از داده‌های سیستم خروجی بگیرید.</p>
                
                <div class="export-buttons">
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                        <input type="hidden" name="action" value="export_data">
                        <input type="hidden" name="export_type" value="users">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-users"></i> خروجی کاربران (JSON)</button>
                    </form>
                    
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                        <input type="hidden" name="action" value="export_data">
                        <input type="hidden" name="export_type" value="conversations">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-comments"></i> خروجی گفتگوها (JSON)</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال مسدود کردن کاربر -->
    <div class="modal" id="ban-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle"></i> مسدود کردن کاربر</h3>
                <button class="close-modal" onclick="closeModal('ban-modal')">&times;</button>
            </div>
            <form method="POST" id="ban-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['admin_csrf_token']; ?>">
                <input type="hidden" name="action" value="ban_user">
                <input type="hidden" name="ban_status" value="1">
                <input type="hidden" name="user_id" id="ban-user-id">
                
                <div class="form-group">
                    <label for="ban_reason">دلیل مسدودسازی:</label>
                    <input type="text" id="ban_reason" name="ban_reason" placeholder="دلیل مسدود کردن کاربر را وارد کنید..." required>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('ban-modal')">لغو</button>
                    <button type="submit" class="btn btn-danger">مسدود کردن</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // مدیریت منوی موبایل
        document.getElementById('menuToggle').addEventListener('click', function() {
            const sidebarNav = document.getElementById('sidebarNav');
            sidebarNav.classList.toggle('show');
        });
        
        // بستن پیام‌های alert
        document.querySelectorAll('.close-alert').forEach(button => {
            button.addEventListener('click', function() {
                this.parentElement.style.display = 'none';
            });
        });
        
        // مدیریت مودال‌ها
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        function openBanModal(userId) {
            document.getElementById('ban-user-id').value = userId;
            document.getElementById('ban_reason').value = '';
            openModal('ban-modal');
        }
        
        // نمودار آمار
        const ctx = document.getElementById('statsChart').getContext('2d');
        const statsChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['کاربران کل', 'کاربران فعال', 'کاربران مسدود', 'پیام‌های کل'],
                datasets: [{
                    label: 'آمار سیستم',
                    data: [
                        <?php echo $stats['total_users']; ?>,
                        <?php echo $stats['active_users']; ?>,
                        <?php echo $stats['banned_users']; ?>,
                        <?php echo $stats['total_messages']; ?>
                    ],
                    backgroundColor: [
                        'rgba(52, 152, 219, 0.7)',
                        'rgba(46, 204, 113, 0.7)',
                        'rgba(231, 76, 60, 0.7)',
                        'rgba(241, 196, 15, 0.7)'
                    ],
                    borderColor: [
                        'rgba(52, 152, 219, 1)',
                        'rgba(46, 204, 113, 1)',
                        'rgba(231, 76, 60, 1)',
                        'rgba(241, 196, 15, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        // اسکرول به بخش‌های مختلف
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.addEventListener('click', function(e) {
                if (this.getAttribute('href').startsWith('#')) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href').substring(1);
                    const targetElement = document.getElementById(targetId);
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth' });
                    }
                    
                    // بستن منو در حالت موبایل
                    if (window.innerWidth < 768) {
                        document.getElementById('sidebarNav').classList.remove('show');
                    }
                }
            });
        });
        
        // تأییدیه برای اقدامات حساس
        document.querySelectorAll('form').forEach(form => {
            if (form.querySelector('button[type="submit"].btn-danger') || form.querySelector('button[type="submit"].btn-warning')) {
                form.addEventListener('submit', function(e) {
                    if (!confirm('آیا از انجام این عمل اطمینان دارید؟')) {
                        e.preventDefault();
                    }
                });
            }
        });
    </script>
</body>
</html>