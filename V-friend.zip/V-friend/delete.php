<?php

function removeJsonById($jsonFile, $searchId) {
    // خواندن محتویات فایل JSON
    $jsonData = file_get_contents($jsonFile);
    
    // تبدیل داده‌ها به آرایه
    $dataArray = json_decode($jsonData, true);

    // بررسی اعتبار تبدیل JSON
    if ($dataArray === null) {
        die(json_encode(["error" => "خطا در پردازش JSON"]));
    }

    // فیلتر کردن آیتم‌هایی که دارای آیدی مشخص نیستند
    $filteredArray = array_filter($dataArray, function ($item) use ($searchId) {
        return !(isset($item['id']) && $item['id'] == $searchId);
    });

    // ذخیره آرایه جدید در فایل JSON
    file_put_contents($jsonFile, json_encode(array_values($filteredArray), JSON_PRETTY_PRINT));

    return ["success" => "آیتم‌های دارای آیدی $searchId حذف شدند"];
}

// بررسی دریافت آیدی از طریق GET
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $searchId = $_GET['id'];
    
    // مسیر فایل JSON
    $jsonFile = 'conversations.json';

    // اجرای حذف
    $response = removeJsonById($jsonFile, $searchId);

    // تنظیم هدر و نمایش نتیجه
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo json_encode(["error" => "لطفاً یک آیدی معتبر وارد کنید."]);
}

?>