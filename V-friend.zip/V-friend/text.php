<?php
header("Content-Type: application/json");

// خواندن فایل JSON از text.json
$jsonData = file_get_contents("text.json");
$quotesArray = json_decode($jsonData, true);

// بررسی صحت JSON و جلوگیری از خطا
if (!is_array($quotesArray) || empty($quotesArray)) {
    echo json_encode(["Text" => "فایل JSON نامعتبر یا خالی است"], JSON_UNESCAPED_UNICODE);
    exit;
}

// فیلتر کردن فقط مقادیر "Text" و نادیده گرفتن "Number"
$validQuotes = array_filter($quotesArray, function ($quote) {
    return isset($quote["Text"]) && !empty($quote["Text"]);
});

// بررسی اگر آرایه فیلتر شده خالی است
if (empty($validQuotes)) {
    echo json_encode(["Text" => "هیچ جمله‌ای در فایل JSON یافت نشد!"], JSON_UNESCAPED_UNICODE);
    exit;
}

// انتخاب تصادفی یک جمله
$randomIndex = array_rand($validQuotes);
$randomQuote = $validQuotes[$randomIndex]["Text"];

// نمایش خروجی فقط شامل "Text"
echo json_encode(["Text" => $randomQuote], JSON_UNESCAPED_UNICODE);
?>